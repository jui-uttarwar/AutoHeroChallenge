package com.Autohero_challenge;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.google.common.collect.Ordering;


public class Autohero 
{
	
	WebDriver driver;

    By firstregistration = By.id("yearFilter");
    By fromdropDown = By.xpath("//*[@id='yearFilter']/following-sibling::div//select[@id='rangeStart']");
    By sortBy =By.id("sortBy");
    By allcontainers = By.xpath("//*[@class='ReactVirtualized__Grid__innerScrollContainer']/div");

    public Autohero(WebDriver driver){

        this.driver = driver;

    }
    
    public void selectFirstRegistrationDropdown(String firstRegistrationYear)
    {
    	 driver.findElement(firstregistration).click();
    	Select first = new Select(driver.findElement(fromdropDown));
    	first.selectByVisibleText(firstRegistrationYear);
    	driver.findElement(firstregistration).sendKeys(Keys.TAB);
    	
    	
    }
    
    public void selectSortDropdown()
    {
    	
    	Select sort = new Select(driver.findElement(sortBy));
    	sort.selectByIndex(2);
    	
    	
    }
    public boolean validateSortDesc()
    {
    	List<WebElement> elementName = driver.findElements(allcontainers);
    	List<Double> value = new ArrayList<Double>();
		for (int i=0; i<elementName.size();i++){
			String s=driver.findElement(By.xpath("//*[@class='ReactVirtualized__Grid__innerScrollContainer']/div["+(i+1)+"]//div[@data-qa-selector='price']")).getText();
		    double z=Double.parseDouble(s.substring(0, 5));
		    value.add(z);
		    
		   
		}
		 boolean sorted = Ordering.natural().isOrdered(value);
		    System.out.println(sorted);
		    return sorted;
		}
    

    public boolean validateFirstRegistration()
    {
    	List<WebElement> elementName = driver.findElements(allcontainers);
		for (int i=0; i<elementName.size();i++){
			String s=driver.findElement(By.xpath("//*[@class='ReactVirtualized__Grid__innerScrollContainer']/div["+(i+1)+"]//li[1]")).getText();
			int value=  Integer.parseInt(s);
			 if(value<2015)
			 {
				 System.out.println("Fail");
				return false;
			 }
			 
    }
		return true;
		}
}

