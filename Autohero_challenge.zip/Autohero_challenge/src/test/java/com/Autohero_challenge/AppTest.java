package com.Autohero_challenge;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
	public String baseUrl = "https://www.autohero.com/de/search/";  
	String driverPath = "C://Users//karan//OneDrive//Desktop//Project//chromedriver_win32//chromedriver.exe";  
	public WebDriver driver ; 
	Autohero auto; 

	
	
	
	@BeforeTest             
	public void launch() throws InterruptedException {      
	// set the system property for Chrome driver      
	System.setProperty("webdriver.chrome.driver", driverPath);  
	// Create driver object for CHROME browser  

	driver = new ChromeDriver();  
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
	driver.manage().window().maximize();  
	driver.get(baseUrl);
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
	 auto=new Autohero(driver);
	 
	}
	//
	    
	 @Test
	public void validateFirstRegistration() throws InterruptedException {   
	
			auto.selectFirstRegistrationDropdown("2015");	
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			Assert.assertTrue(auto.validateFirstRegistration());
			
			
	}     
	 @Test
		public void validateDescending() throws InterruptedException {    
		 auto.selectSortDropdown();	
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 Assert.assertFalse(auto.validateSortDesc());
					  
		}     
	@AfterTest  
	public void afterTest() {  
	driver.quit();  
	System.out.println("after test");  
	}        
}